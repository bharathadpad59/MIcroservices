package com.socialmedia.userapplication.pojo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(value = {"field1","field2"}) //static filtering
public class StaticBean {

	String field1;
	String field2;
	@JsonIgnore //Static filtering
	String field3;
	String field4;
	
}
