Insert into USERS(user_id, user_name, dept_name) values(4,'Rock','Wrestler');
Insert into USERS(user_id, user_name, dept_name) values(3,'Shaun','Finance');
Insert into USERS(user_id, user_name, dept_name) values(6,'Brock','Wrestler');
Insert into USERS(user_id, user_name, dept_name) values(7,'AJ-STYLES','Marketing');

commit;

Insert into Posts(post_id, post_name,user_user_id) values(101, 'Rameshwaram', 4);
Insert into Posts(post_id, post_name,user_user_id) values(102, 'Shegaon', 4);
Insert into Posts(post_id, post_name,user_user_id) values(103, 'Pachmarhi', 6);
Insert into Posts(post_id, post_name,user_user_id) values(1014, 'Tirupati', 7);
Insert into Posts(post_id, post_name,user_user_id) values(1015, 'Bodh Gaya', 7);
Insert into Posts(post_id, post_name,user_user_id) values(1016, 'Kashi Banaras', 4);
Insert into Posts(post_id, post_name,user_user_id) values(106, 'Pandhrapur', 4);
Insert into Posts(post_id, post_name,user_user_id) values(107, 'Shirdi', 3);

commit;

Insert into Departments values(1, 'Finance');
Insert into Departments values(2, 'Marketing');
Insert into Departments values(3, 'Wrestler');

commit;
