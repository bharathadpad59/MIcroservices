package com.service.currencyconversion.proxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.service.currencyconversion.entity.CurrencyConversion;

//@FeignClient(name = "currency-exchange", url = "localhost:8082")
@FeignClient(name = "currency-exchange")
public interface CurrencyExchangeProxy {

	@GetMapping("/currency-exchange/{from}/to/{to}")
	public CurrencyConversion getCurrencyExchangeService(@PathVariable String from, @PathVariable String to);
}
