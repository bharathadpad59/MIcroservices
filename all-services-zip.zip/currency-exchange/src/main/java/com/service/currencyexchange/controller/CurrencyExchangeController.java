package com.service.currencyexchange.controller;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.service.currencyexchange.configuration.ConfigProperties;
import com.service.currencyexchange.entity.CurrencyExchange;
import com.service.currencyexchange.repo.CurrencyExchangeRepo;

@RestController
public class CurrencyExchangeController {
	Logger log = LoggerFactory.getLogger(CurrencyExchangeController.class);

	@Autowired
	Environment environment;

	@Autowired
	CurrencyExchangeRepo currencyExchangeRepo;
	
	@Autowired
	ConfigProperties configProperties;

	@GetMapping("/currency-exchange/{from}/to/{to}")
	public CurrencyExchange getCurrencyExchangeService(@PathVariable String from, @PathVariable String to) {
		CurrencyExchange currencyExchange = currencyExchangeRepo.findByFromAndTo(from, to);
		if (!Optional.ofNullable(currencyExchange).isPresent()) {
			throw new RuntimeException("No currency exchange present");
		}
		log.info("ConfigProperties=================>>>>>>>>>>>>>>>"+configProperties.getUsername()+" "+
		configProperties.getPassword());
		currencyExchange.setEnvironment(environment.getProperty("local.server.port"));
		return currencyExchange;
	}

}
