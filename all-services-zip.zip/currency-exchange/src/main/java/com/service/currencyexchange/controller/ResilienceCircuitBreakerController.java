package com.service.currencyexchange.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import io.github.resilience4j.bulkhead.annotation.Bulkhead;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.ratelimiter.annotation.RateLimiter;
import io.github.resilience4j.retry.annotation.Retry;

@RestController
public class ResilienceCircuitBreakerController {
	Logger log= LoggerFactory.getLogger(ResilienceCircuitBreakerController.class);
	@GetMapping("/circuit-breaker")
	@Retry(name = "default") //this will retry 3 times,If we want to cofigure lets say 4-5 reties,
																	//	we can do it in prop file
//	@Retry(name = "custom-retry",fallbackMethod = "handleFallback")
	@CircuitBreaker(name = "default", fallbackMethod = "handleFallback")
	@RateLimiter(name = "cicuit-breaker")
	@Bulkhead(name = "circuit-breaker")
	public String getResponse() {
		log.info("Inside Circuir breaker pattern method");
//		ResponseEntity<String> body= new RestTemplate()
//				.getForEntity("htttp://localhost:8080/dumy", String.class);
//		return body.getBody();
		return "Rate Limiter";
	}
	
	public String handleFallback(Exception ex) {
		log.info("Inside circuit breaker fallback method");
		return "Fallback Response";
	}
}
