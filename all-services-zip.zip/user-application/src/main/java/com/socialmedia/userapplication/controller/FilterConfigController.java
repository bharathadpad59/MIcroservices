package com.socialmedia.userapplication.controller;

import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ser.FilterProvider;
import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;
import com.fasterxml.jackson.databind.ser.impl.SimpleFilterProvider;
import com.socialmedia.userapplication.pojo.DynamicBean;
import com.socialmedia.userapplication.pojo.StaticBean;

@RestController
public class FilterConfigController {

	@GetMapping("/static-filter")
	public StaticBean retrieveSomeBeansStatically() {
		return new StaticBean("field-1", "field-2", "field-3", "field-4");
	}

	@GetMapping("/dynamic-filter")
	public MappingJacksonValue retrieveSomeBeansDynamically() {
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("field1", "field4");
		FilterProvider filters = new SimpleFilterProvider().addFilter("DynamicFilter", filter);
		MappingJacksonValue mapvalue = new MappingJacksonValue(
				new DynamicBean("field-1", "field-2", "field-3", "field-4"));
		mapvalue.setFilters(filters);
		return mapvalue;
	}

}
